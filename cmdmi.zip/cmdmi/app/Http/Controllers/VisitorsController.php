<?php

namespace App\Http\Controllers;
use Illuminate\Database\QueryException;

use Mail;
use App\visitors;
use App\ErrorCode;
use App\ErrorDesc;
use App\MyResponse;
use App\User;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;

class VisitorsController extends Controller
{

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $reg_date       = Carbon::now('Asia/Jakarta');
        $user           = User::where('id',$request['user_id'])->where('remember_token',$request['token'])->first();
        if (empty($user)){
            $response   = new MyResponse(ErrorCode::$ACCESS_DENIED, ErrorDesc::$ACCESS_DENIED,"");
            return $response->get();
        }

        $visitors = new visitors();
        $visitors['created_at']  = $reg_date;
        $visitors['name']  = $request['name'];
        $visitors['email'] = $request['email'];
        $visitors['phone'] = $request['phone'];
        $visitors['motorcycle']  = $request['motorcycle'];
        $visitors['probability'] = $request['probability'];
        $visitors['user'] = $user['id'];

        $user           = User::where('user_name',$request['user_id'])->where('remember_token',$request['token'])->first();

        try {
            $visitors->save();
            Mail::send('email', compact('visitors'), function($message) use($visitors) {
                $message->from('royalenfield@distributormotor.com','PT. Distributor Motor Indonesia');
                $message->to($visitors['email'])->subject('Royal Enfield Subscription');
            });

            $response   = new MyResponse(ErrorCode::$OK, ErrorDesc::$OK,$visitors);
            return $response->get();
        } catch (QueryException $ex) {
            $response   = new MyResponse(ErrorCode::$ERROR_REGISTER, ErrorDesc::$ERROR_REGISTER,$ex->getMessage());
            return $response->get();
        }
       
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\visitors  $visitors
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        // dd(phpinfo());
        // $visitors = DB::select("call report('1')");
        $visitors = DB::table("api_visitors")->leftJoin('api_users', 'api_visitors.user', '=', 'api_users.id')->orderBy('created_at','desc')->select('api_visitors.*', 'api_users.name as created_by')->paginate(13);
        // $data  = visitors::orderBy('created_at','desc')->paginate(13);
        // return $visitors;
        // $visitors  = visitors::orderBy('created_at','desc')->paginate(13);
        return view('welcome',compact('visitors'))->with('i', ($request->input('page', 1) - 1) * 13);
    }



    public function downloadExcel(){
            $data_arr =  DB::table("api_visitors")->leftJoin('api_users', 'api_visitors.user', '=', 'api_users.id')->orderBy('created_at','desc')->select('api_visitors.*', 'api_users.name as created_by')->get()->toArray();
        // $data = visitors::get()->toArray();
        // return $data;
        $data = json_decode(json_encode($data_arr), true);
        Excel::create('DMI Report 2018', function($excel) use ($data){
             $excel->setTitle('Report 2018');
             $excel->setCreator('Me')->setCompany('DMI');
             $excel->setDescription('Report DMI');
             
    
            $excel->sheet('Sheet 1', function ($sheet) use ($data) {
               
                $sheet->setOrientation('landscape');
                // $sheet->fromArray($data);
                $sheet->cell('A1', function($cell) use($data) {
                    $cell->setBackground('#000111');
                    $cell->setFontColor('#ffffff');
                    $cell->setAlignment('center');
                    $cell->setFontSize(12);
                    $cell->setValue('No.');
                });
                $sheet->setSize('A1',  5, 22); 

                $sheet->cell('B1', function($cell) use($data) {
                    $cell->setBackground('#000111');
                     $cell->setFontColor('#ffffff');
                    $cell->setAlignment('center');
                    $cell->setFontSize(12);
                    $cell->setValue('Date');
                });
                $sheet->cell('C1', function($cell) use($data) {
                    $cell->setBackground('#000111');
                     $cell->setFontColor('#ffffff');
                    $cell->setAlignment('center');
                    $cell->setFontSize(12);
                    $cell->setValue('Name');
                });
                $sheet->cell('D1', function($cell) use($data) {
                    $cell->setBackground('#000111');
                     $cell->setFontColor('#ffffff');
                    $cell->setAlignment('center');
                    $cell->setFontSize(12);
                    $cell->setValue('Motorcycle of Interest');
                });
                $sheet->cell('E1', function($cell) use($data) {
                    $cell->setBackground('#000111');
                     $cell->setFontColor('#ffffff');
                    $cell->setAlignment('center');
                    $cell->setFontSize(12);
                    $cell->setValue('Likely to purchase');
                });
                $sheet->cell('F1', function($cell) use($data) {
                    $cell->setBackground('#000111');
                     $cell->setFontColor('#ffffff');
                    $cell->setAlignment('center');
                    $cell->setFontSize(12);
                    $cell->setValue('Contact No.');
                });
                $sheet->cell('G1', function($cell) use($data) {
                    $cell->setBackground('#000111');
                    $cell->setFontColor('#ffffff');
                    $cell->setAlignment('center');
                    $cell->setFontSize(12);
                    $cell->setValue('Email Address');
                });
                $sheet->cell('H1', function($cell) use($data) {
                    $cell->setBackground('#000111');
                    $cell->setFontColor('#ffffff');
                    $cell->setAlignment('center');
                    $cell->setFontSize(12);
                    $cell->setValue('Created By');
                });
                if (!empty($data)) {
                    $number = 1;
                    foreach ($data as $key => $value) {
                        $i= $key+2;
                        $sheet->cell('A'.$i,  $number); 
                        $sheet->cell('B'.$i, $value['created_at']); 
                        $sheet->cell('C'.$i, $value['name']); 
                        $sheet->cell('D'.$i, $value['motorcycle']); 
                        $sheet->cell('E'.$i, $value['probability']); 
                        $sheet->cell('F'.$i, $value['phone']); 
                        $sheet->cell('G'.$i, $value['email']); 
                        $sheet->cell('H'.$i, $value['created_by']); 

                         $sheet->setSize('A'.$i,  5, 18); 
                         $sheet->setSize('B'.$i,  20, 18); 
                         $sheet->setSize('C'.$i,  30, 18); 
                         $sheet->setSize('D'.$i,  20, 18); 
                         $sheet->setSize('E'.$i,  20, 18); 
                         $sheet->setSize('F'.$i,  15, 18); 
                         $sheet->setSize('G'.$i,  27, 18); 
                         $sheet->setSize('H'.$i,  27, 18); 
            

                         $number++;
                    }
                }
            });
        })->download('xls');
    }

    public function test(){
        return view('email');
    }


    // public function generateExcel($data=[]){
    //     Excel::create("Tesst", function($excel) use($data) {
    //     $excel->sheet($sheetTitle, function($sheet) use($data,$sheetTitle) {
    //         $row=1;
    //         $rangeCell=getExcelCol(count($data['allColumn']));
    //         $sheet->mergeCells('A'.$row.':'.$rangeCell.$row);
    //         $sheet->cell('A'.$row, function($cell) use($data) {
    //             $cell->setValue("Title");
    //             $cell->setBackground('#F7D90E');
    //             $cell->setAlignment('center');
    //             $cell->setFontSize(16);
    //         });
    //         if(!empty($data['allColumn'])) {
    //             $sheet->appendRow($row,$data['allColumn']);
    //             $row++;
    //         }
    //         if(!empty($data['formatColumn'])) $sheet->setColumnFormat($data['formatColumn']);
    //         $orderNo=0;
    //         $z=$x=$row;
    //         // dd($data['valRow']);
    //         foreach ($data['valRow'][$sheetTitle] as $array) {
    //             $sheet->appendRow($row,$array);
    //             $row++;
    //         }
    //     });
    //     })->download('xlsx');
    // }

}
