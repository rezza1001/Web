<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\User;
use App\ErrorCode;
use App\ErrorDesc;
use App\MyResponse;

class LoginMobile extends Controller 
{
    public function index()
    {
        return "Login Mobile Controller";
    }

    public function login(Request $request)
    {
    	 $email 	= $request['email'];
    	 $password 	= $request['password'];
    	 $datalogin = $this->chekLogin( $email , $password);
	  	if ( $datalogin != ErrorCode::$ERROR_LOGIN) {
	  		$user  			= User::find($datalogin['id']);

	  		if ($this->checkImei($user, $request)){
	  			$user['remember_token'] 	= $user-> generateToken();
	  			$user['imei'] 	= $request['imei'];
		  		$user->update();
	  			$respnse = new MyResponse(ErrorCode::$OK, ErrorDesc::$OK, $user );
				return $respnse->get() ;
	  		}
	  		else {
	  			$respnse = new MyResponse(ErrorCode::$ERROR_LOGIN, ErrorDesc::$ERROR_LOGIN,'-');
				return $respnse->get() ;
	  		}
		}
		else {
		  	$respnse = new MyResponse(ErrorCode::$ERROR_LOGIN, ErrorDesc::$ERROR_LOGIN,'-');
			return $respnse->get() ;
		}
	}

	public function checkImei(User $user, Request $request)
	{
		if ($user['imei'] == NULL){
			return true;
		}
		else {
			if ($user['imei'] != $request['imei'] ){
				return false;
			}
			else {
				return true;
			}
			
		}

	}

	public function chekLogin( $email , $password){
		$data = DB::select("call login('".$email."','".$password."')");
		$user = new User();
		$data_arr = json_decode(json_encode($data), true);

		if (count($data_arr) == 0){
			return ErrorCode::$ERROR_LOGIN;
		}
		else {
			$user['id'] 		= $data_arr[0]['id'];
			$user['user_name'] 	= $data_arr[0]['user_name'];
			$user['name'] 		= $data_arr[0]['name'];
			$user['type'] 		= $data_arr[0]['type'];
			return $user;
		}
	}


}
