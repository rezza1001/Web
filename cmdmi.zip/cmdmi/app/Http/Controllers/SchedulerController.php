<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\visitors;

class SchedulerController extends Controller
{
   
   public function testData(){
   	    $visitors = new visitors();
        $visitors['name']  = "Test User Scheduler";
        $visitors['email'] = "user_scheduler@gmail.com";
        $visitors['phone'] = "0878878988222";
        $visitors['motorcycle']  = "Himalayan";
        $visitors['probability'] = "1 Month";
         $visitors->save();
   }
}
