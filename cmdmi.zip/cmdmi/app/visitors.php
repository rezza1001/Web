<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class visitors extends Model
{
	protected $table 	= 'api_visitors';
    protected $fillable = [
     	'id','name','email', 'phone','motorcycle','probability','created_at'
    ];
}
