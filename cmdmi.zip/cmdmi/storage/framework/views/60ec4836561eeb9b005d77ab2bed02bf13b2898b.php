    <!DOCTYPE html>
    <html>
    <head>
        <title>DMI</title>
          <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <style>
            .header {
                background-color: #000111 !important;
                color: #f4f5f7 !important;
            }
            .btn-info {
                color: #fff!important;
                background-color: #0c1421!important;
                border-color: #0c1421!important;
            }
            .btn-info:hover {
                color: #fff!important;
                background-color: #273751!important;
                border-color: #273751!important;
            }
        </style>
        
         <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
         
          
          

        <script type="text/javascript">
            function downloadData(){
                  $.ajax({
                      method: "GET",
                      url:"/downloadexcel",
                      data: {_token: $('meta[name="csrf-token"]').attr('content')},
                    }).done(function(data) {
                     console.log(data);
                    }).fail(function (jqXHR, textStatus, errorThrown) {
                       console.log(errorThrown);
                     });

            }
       </script>

    </head>
    <body>
    <div class="container">
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                <tr class="heading">
                    <th  class="header">No</th>
                    <th  class="header">Name</th>
                    <th  class="header">Motorcycle of interest</th>
                    <th  class="header">Likely to purchase</th>
                    <th class="header">Contact No.</th>
                    <th  class="header">Email Address</th>
                </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $visitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$i); ?></td>
                            <td><?php echo $visitor->name; ?></td>
                            <td><?php echo $visitor->motorcycle; ?></td>
                            <td><?php echo $visitor->probability; ?></td>
                            <td><?php echo $visitor->phone; ?></td>
                            <td><?php echo $visitor->email; ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div>
               <div class="col-md-6">
                  <ul class="pager" style="text-align: left">
                      <li>
                        <a href="<?php echo e(URL::to('downloadexcel')); ?>" class="btn btn-info btn-lg">
                          <span class="glyphicon glyphicon-save"></span> Download 
                        </a>
                       
                      </li>
                  </ul>
                </div>
                <div class="col-md-6">
                    <?php echo $visitors->links('pagination'); ?>

                </div>
          </div>
          
        </div>
    </div>
    </body>

    </html>