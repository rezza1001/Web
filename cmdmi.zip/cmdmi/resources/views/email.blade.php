<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style type="text/css">
      .textstyle{
        font-family: "Helvetica Neue";
        font-size: 100%;
      }
      .textstyle2{
        font-family: "arial,sans-serif";
        font-size: 100%;
      }
      .textstyle3{
        margin:0px; font-size: 100%;font-variant-numeric:normal;font-variant-east-asian:normal;font-stretch:normal;line-height:normal;
      }
  </style>
</head>
<body>

<div class="container">
  <div class="row">
    <div class="col-md-12" style="margin-top: 10px">
        <!-- <img src="http://test.mybarber.my.id/images/dmi.png" style="width: 100px; height: 50px"> -->
        <img src="http://test.mybarber.my.id/images/re.png" style="width: 100px; height: 50px; margin-left: 0px">
    </div>
  </div>
  <div class="row">
    <div class="col-md-12">
       <hr/>
    </div>
  </div>
   <div class="row">
    <div class="col-md-12">
       <p class="textstyle">Dear Valuable Customers,</p>
       <p class="textstyle">You are receiving this email because you opted-in on our Booth at IIMS 2018. Thank you for your interest in <b>Royal Enfield.</b> 
       <br/>
       Feel free to contact our Authorized dealer for more information and test-ride registration:</p>
    </div>
  </div>
  <div class="row">
    <div class="col-md-12"> 
        <p class="textstyle"><b>Royal Enfield Exclusive Store</b>
          <a class="textstyle2" href="https://maps.google.com/?q=Jakarta+%C2%A0+Jl.+Pejaten+Barat+No.5,+Jakarta+Selatan&amp;entry=gmail&amp;source=g"><u>Jakarta</u> <br/><u>Jl. Pejaten Barat No.5, Jakarta Selatan</u></a>
            <br>
            <tag class="textstyle3">T/WA : +622171795082 / +628111441901</tag>
        </p>
     </div>

      <div class="col-md-12"> 
        <p class="textstyle"><b>Royal Enfield Exclusive Store</b>
          <a class="textstyle2" href="https://maps.google.com/?q=Bali+Jl.+Sunset+Road+No.27,+Kuta-Bali&entry=gmail&source=g"><u>Bali</u> <br/><u>Jl. Sunset Road No.27, Kuta-Bali</u></a>
            <br>
            <tag class="textstyle3">T/WA : +623614754960 / +628111141901</tag>
        </p>
     </div>

    <div class="col-md-12"> 
        <p class="textstyle"><b>Royal Enfield Exclusive Gear Store</b>
          <a class="textstyle2" href="https://maps.google.com/?q=1,+Jl.+Metro+Pondok+Indah&entry=gmail&source=g"><br/><u>Pondok Indah Mall 2 Lt. 1, Jl. Metro Pondok Indah</u></a>
            <br>
            <tag class="textstyle3">T/WA : +622175920634 / +628111181901</tag>
        </p>
     </div>

    <div class="col-md-12"> 
        <p class="textstyle"><b>Royal Enfield Authorized Service Center</b>
          <tag1 class="textstyle2" ><br/>Bursa Mobil BSD Blok C3, Jl. BSD Raya Utama, Tangerang-Banten</tag1>
            <br>
            <tag class="textstyle3">T/WA : +628111731901</tag>
        </p>
     </div>

     <div class="col-md-12"> 
        <p class="textstyle">Please visit our social media for our upcoming events & promotions :
          <br>
            <a href="https://www.instagram.com/royalenfieldid/?hl=en" target="_blank" data-saferedirecturl="https://www.google.com/url?hl=en&amp;q=https://www.instagram.com/royalenfieldid/?hl%3Den&amp;source=gmail&amp;ust=1523864372493000&amp;usg=AFQjCNGNbXJWZGZ1aHKnigAED2rsc53nNA">https://www.instagram.com/<wbr>royalenfieldid/?hl=en</a>
        </p>
     </div>


      <div class="col-md-12"> 
        <p class="textstyle">Best regards, 
          <br>
          PT. Distributor Motor Indonesia
          <br>
          Royal Enfield Exclusive Store
        </p>
     </div>

  </div>
</div>

</body>
</html>
