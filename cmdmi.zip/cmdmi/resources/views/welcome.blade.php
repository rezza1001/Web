    <!DOCTYPE html>
    <html>
    <head>
        <title>DMI Report</title>
          <meta name="csrf-token" content="{{ csrf_token() }}">
        <style>
            .header {
                background-color: #000111 !important;
                color: #f4f5f7 !important;
            }
            .btn-info {
                color: #fff!important;
                background-color: #0c1421!important;
                border-color: #0c1421!important;
            }
            .btn-info:hover {
                color: #fff!important;
                background-color: #273751!important;
                border-color: #273751!important;
            }
        </style>
        {{-- <link rel="stylesheet" type="text/css" href="http://www.expertphp.in/css/bootstrap.css"> --}}
         <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
         {{-- <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script> --}}
          {{-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> --}}
          {{-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script> --}}

        <script type="text/javascript">
            function downloadData(){
                  $.ajax({
                      method: "GET",
                      url:"/downloadexcel",
                      data: {_token: $('meta[name="csrf-token"]').attr('content')},
                    }).done(function(data) {
                     console.log(data);
                    }).fail(function (jqXHR, textStatus, errorThrown) {
                       console.log(errorThrown);
                     });

            }
       </script>

    </head>
    <body>
    <div class="container">
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                <tr class="heading">
                    <th  class="header">No</th>
                    <th  class="header">Date</th>
                    <th  class="header">Name</th>
                    <th  class="header">Motorcycle of interest</th>
                    <th  class="header">Likely to purchase</th>
                    <th class="header">Contact No.</th>
                    <th  class="header">Email Address</th>
                    <th  class="header">Created By</th>
                </tr>
                </thead>
                <tbody>
                    @foreach ($visitors as $visitor)
                        <tr>
                            <td>{{ ++$i }}</td>
                 {{--            <td>{!! substr($visitor->created_at,0,11) !!}</td> --}}
                            <td>{!! $visitor->created_at !!}</td>
                            <td>{!! $visitor->name !!}</td>
                            <td>{!! $visitor->motorcycle !!}</td>
                            <td>{!! $visitor->probability !!}</td>
                            <td>{!! $visitor->phone !!}</td>
                            <td>{!! $visitor->email !!}</td>
                            <td>{!! $visitor->created_by !!}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
            <div>
               <div class="col-md-6">
                  <ul class="pager" style="text-align: left">
                      <li>
                        <a href="{{ URL::to('downloadexcel') }}" class="btn btn-info btn-lg">
                          <span class="glyphicon glyphicon-save"></span> Download 
                        </a>
                       
                      </li>
                  </ul>
                </div>
                <div class="col-md-6">
                    {!! $visitors->links('pagination') !!}
                </div>
          </div>
          
        </div>
    </div>
    </body>

    </html>